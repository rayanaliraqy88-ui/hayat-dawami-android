package com.hayat.dawami;
import android.content.*;import android.Manifest;import android.content.pm.PackageManager;import android.os.Build;
import com.google.android.gms.location.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()))return; if(!c.getSharedPreferences("dawami",0).getBoolean("geofence_enabled",false))return;
  if(c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
  if(Build.VERSION.SDK_INT>=29&&c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
  Geofence f=new Geofence.Builder().setRequestId("hayat_hospital").setCircularRegion(36.337866,43.1513406,180).setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER).setExpirationDuration(Geofence.NEVER_EXPIRE).build();
  GeofencingRequest r=new GeofencingRequest.Builder().setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER).addGeofence(f).build();
  try{LocationServices.getGeofencingClient(c).addGeofences(r,GeofenceReceiver.pendingIntent(c));}catch(SecurityException ignored){}
 }
}
