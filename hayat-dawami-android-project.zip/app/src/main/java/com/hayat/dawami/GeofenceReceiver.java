package com.hayat.dawami;
import android.app.*;import android.content.*;import android.os.Build;import androidx.core.app.NotificationCompat;
import com.google.android.gms.location.*;
public class GeofenceReceiver extends BroadcastReceiver {
 public static PendingIntent pendingIntent(Context c){Intent i=new Intent(c,GeofenceReceiver.class);int f=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=23)f|=PendingIntent.FLAG_MUTABLE;return PendingIntent.getBroadcast(c,77,i,f);}
 @Override public void onReceive(Context c,Intent i){GeofencingEvent e=GeofencingEvent.fromIntent(i);if(e==null||e.hasError()||e.getGeofenceTransition()!=Geofence.GEOFENCE_TRANSITION_ENTER)return;
  String day=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(new java.util.Date());SharedPreferences p=c.getSharedPreferences("dawami",0);if(p.getBoolean("duty_"+day,false)||p.getBoolean("notice_"+day,false))return;p.edit().putBoolean("notice_"+day,true).apply();
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("dawami_arrival","تنبيه الوصول للمستشفى",NotificationManager.IMPORTANCE_HIGH));
  Notification n=new NotificationCompat.Builder(c,"dawami_arrival").setSmallIcon(android.R.drawable.ic_dialog_map).setContentTitle("تذكير تسجيل الدوام").setContentText("أنت الآن بالقرب من مستشفى الحياة، لا تنسَ تسجيل دوامك").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();nm.notify(77,n);
 }
}
