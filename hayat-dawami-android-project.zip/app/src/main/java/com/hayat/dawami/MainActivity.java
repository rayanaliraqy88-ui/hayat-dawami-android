package com.hayat.dawami;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;

public class MainActivity extends Activity {
    private WebView web; private GeofencingClient client;
    private static final double LAT=36.337866, LON=43.1513406;
    private static final int REQ=501;
    @Override public void onCreate(Bundle b){super.onCreate(b); client=LocationServices.getGeofencingClient(this);
        web=new WebView(this); setContentView(web); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"AndroidGeofence");
        web.loadUrl("file:///android_asset/index.html"); createChannel(); }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){android.app.NotificationChannel c=new android.app.NotificationChannel("dawami_arrival","تنبيه الوصول للمستشفى",android.app.NotificationManager.IMPORTANCE_HIGH); getSystemService(android.app.NotificationManager.class).createNotificationChannel(c);} }
    private boolean hasFine(){return ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private boolean hasBackground(){return Build.VERSION.SDK_INT<29 || ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private boolean hasNotify(){return Build.VERSION.SDK_INT<33 || ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    private void registerFence(){
        if(!hasFine() || !hasBackground()){ Toast.makeText(this,"اسمح بالموقع طوال الوقت من إعدادات التطبيق ثم أعد التفعيل",Toast.LENGTH_LONG).show(); return; }
        Geofence fence=new Geofence.Builder().setRequestId("hayat_hospital").setCircularRegion(LAT,LON,180).setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER).setExpirationDuration(Geofence.NEVER_EXPIRE).setLoiteringDelay(0).build();
        GeofencingRequest req=new GeofencingRequest.Builder().setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER).addGeofence(fence).build();
        try { client.addGeofences(req,GeofenceReceiver.pendingIntent(this)).addOnSuccessListener(v->{getPreferences(0).edit().putBoolean("enabled",true).apply();getSharedPreferences("dawami",0).edit().putBoolean("geofence_enabled",true).apply(); Toast.makeText(this,"تم تفعيل تنبيه الوصول",Toast.LENGTH_SHORT).show();}).addOnFailureListener(e->Toast.makeText(this,"تعذر تفعيل الموقع: "+e.getMessage(),Toast.LENGTH_LONG).show()); } catch(SecurityException e){Toast.makeText(this,"تحقق من صلاحيات الموقع",Toast.LENGTH_LONG).show();}
    }
    private class Bridge {
        @JavascriptInterface public void enableGeofence(){runOnUiThread(()->{
            if(!hasFine()){ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ);return;}
            if(Build.VERSION.SDK_INT>=29 && !hasBackground()){ try{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception e){} Toast.makeText(MainActivity.this,"اختر الموقع ثم السماح طوال الوقت، وبعدها ارجع واضغط تفعيل مرة ثانية",Toast.LENGTH_LONG).show();return;}
            if(Build.VERSION.SDK_INT>=33&&!hasNotify()) ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ+1);
            registerFence(); });}
        @JavascriptInterface public void disableGeofence(){runOnUiThread(()->{client.removeGeofences(GeofenceReceiver.pendingIntent(MainActivity.this));getPreferences(0).edit().putBoolean("enabled",false).apply();getSharedPreferences("dawami",0).edit().putBoolean("geofence_enabled",false).apply();Toast.makeText(MainActivity.this,"تم إيقاف تنبيه الموقع",Toast.LENGTH_SHORT).show();});}
        @JavascriptInterface public void setDutyRecorded(String date, boolean recorded){getSharedPreferences("dawami",0).edit().putBoolean("duty_"+date,recorded).apply();}
        @JavascriptInterface public boolean isEnabled(){return getPreferences(0).getBoolean("enabled",false);}
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==REQ && hasFine()) Toast.makeText(this,"تم السماح بالموقع. اضغط تفعيل مرة ثانية واختر السماح طوال الوقت",Toast.LENGTH_LONG).show(); else if(r==REQ+1) Toast.makeText(this,"يمكنك السماح بالإشعارات من إعدادات التطبيق",Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
